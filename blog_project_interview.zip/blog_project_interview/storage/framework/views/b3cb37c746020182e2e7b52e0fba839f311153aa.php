<div class="mt-6">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Laravel-From-Scratch-Blog-Project-main\resources\views/components/form/field.blade.php ENDPATH**/ ?>