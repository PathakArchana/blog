<div <?php echo e($attributes(['class' => 'border border-gray-200 p-6 rounded-xl'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Laravel-From-Scratch-Blog-Project-main\resources\views/components/panel.blade.php ENDPATH**/ ?>